package com.igate.eshop.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.igate.eshop.entity.SubCategory;


/*****************************************************************************************************************************
 * File Name:	SubCategoryResultSetExtractor 
 * Package Name:	com.igate.eshop.dao
 * Description:	Retrieves the SubCategoryDetails of the Product from the database and sets the values to the SubCategory Bean
 * Version: 	1.0
 * Restrictions:	N/A
 * @author 	aa815803,mk815850,ss815801,ns815843,bv815844,nm815851,kp815871
 * Date:		24/12/2013
 ********************************************************************************************************************************/


@SuppressWarnings("unchecked")
public class SubCategoryResultSetExtractor implements ResultSetExtractor
{
	@Override
	public Object extractData(ResultSet rs) throws SQLException,DataAccessException 
	{
		SubCategory subCategory = new SubCategory();
		subCategory.setSubCategoryName(rs.getString(1));
		subCategory.setCategory(rs.getString(2));
		return subCategory;
	}

}
