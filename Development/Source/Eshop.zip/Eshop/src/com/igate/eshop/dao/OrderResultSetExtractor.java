package com.igate.eshop.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.igate.eshop.entity.Order;


/*****************************************************************************************************************************
 * File Name:	OrderResultSetExtractor 
 * Package Name:	com.igate.eshop.dao
 * Description:	Retrieves the OrderDetails of the Product from the database and sets the values to the Order Bean
 * Version: 	1.0
 * Restrictions:	N/A
 * @author 	aa815803,mk815850,ss815801,ns815843,bv815844,nm815851,kp815871
 * Date:		24/12/2013
 ********************************************************************************************************************************/


public class OrderResultSetExtractor 
{
	public Object extractData(ResultSet rs) throws SQLException 
	{
		Order order = new Order();
		order.setOrderId(rs.getString(1));
		order.setProductId(rs.getString(2));
		order.setCustomerid(rs.getString(3));
		order.setOrderDate((java.util.Date)rs.getDate(4));
		order.setOrderStatus(rs.getString(5));
		order.setTotalPrice(rs.getDouble(6));
		order.setQuantity(rs.getInt(7));

		return order;

	}
}
