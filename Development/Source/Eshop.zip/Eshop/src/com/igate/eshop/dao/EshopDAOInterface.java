package com.igate.eshop.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.igate.eshop.entity.Customer;
import com.igate.eshop.entity.Order;
import com.igate.eshop.entity.Product;
import com.igate.eshop.entity.SubCategory;
import com.igate.eshop.entity.User;
import com.igate.eshop.entity.UserCredentials;

/*******************************************************************************************************
 * File Name:	EshopDAOInterface.java
 * Package Name:	com.igate.eshop.dao
 * Description:	Consists of all the Method Declarations of those methods present in EshopDAOImpl.java 		
 * Version: 	1.0
 * Restrictions:	N/A
 * @author 	aa815803,mk815850,ss815801,ns815843,bv815844,nm815851,kp815871
 * Date:		24/12/2013
******************************************************************************************************/

public interface EshopDAOInterface 
{

	public Product getProductDetails(String productId);
	public  Map<String, List<String>> returnNavigationBarData();
	public  List<Product> getProductDetailsList();
	public  List<Product> getProductDetailsByCategory(String subCategoryName);
	public int registerUser (Customer customer);
	public User searchUser(User user);
	public int isValidUser(User user);
	public List<Product> getProductDetailsByName(String productName);
	public List<Order> getOrderList(int value,Date fromDate,Date toDate);
	public int updateProduct(Product product);
	public List<SubCategory> getSubCategories();
	public int addProduct(Product product);
	public boolean insertOrderDetails(List<Product> cartList, double total, String userId);  
	public int changePassword(UserCredentials user);
	public int isValidUser(UserCredentials user);
	public int isUserExists(User user); 
}
