package com.igate.eshop.entity;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

/*****************************************************************
 * @author bv815844
 *Package:com.igate.eshop.entity
 *Class Name:User
 *Description:This is a POJO class which provides getters and setters for User
 ******************************************************************/
@Component("user")
public class User 
{
	@NotEmpty
	@Pattern(regexp ="[a-zA-Z0-9]*")
	@Size(max = 10) 
	private String userId;


	@NotEmpty
	@Size(max = 16)
	@Pattern(regexp ="[a-zA-Z0-9 ]*")
	private String password;

	private String role;
	/****************************************************************** 
	 * Getter and Setter Methods for User
	 ******************************************************************/


	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getRole() {
		return role;
	}



}

