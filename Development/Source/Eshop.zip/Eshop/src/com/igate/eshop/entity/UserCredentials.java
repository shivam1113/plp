package com.igate.eshop.entity;



import org.hibernate.validator.constraints.NotEmpty;

/***********************************************************************************************************
 * File Name:	UserCredentials
 * Package Name:	com.igate.eshop.entity
 * Description:	Consists of all the properties of the UserCredentials such as userId, password and  newPassword. 
 * Version: 	1.0
 * Restrictions:	N/A
 * @author 	aa815803,mk815850,ss815801,ns815843,bv815844,nm815851,kp815871
 * Date:		24/12/2013
 **********************************************************************************************************/

public class UserCredentials 
{

	@NotEmpty(message="UserName cannot be empty")

	String userId;
	@NotEmpty(message="Password cannot be empty")
	String password;
	@NotEmpty(message="NewPassword cannot be empty")
	String newPassword;

	/****************************************************************** 
	 * Getter and Setter Methods for UserCredentials 
	 ******************************************************************/
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
