package com.igate.eshop.entity;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

/*****************************************************************
 * @author bv815844
 *Package:com.igate.eshop.entity
 *Class Name:SubCategory
 *Description:This is a POJO class which provides getters and setters for SubCategory
 ******************************************************************/

@Component("subCategory")
public class SubCategory {

	String category;
	@NotEmpty
	String subCategoryName;

	/****************************************************************** 
	 * Getter and Setter Methods for SubCategory
	 ******************************************************************/

	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSubCategoryName() {
		return subCategoryName;
	}
	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}
}
