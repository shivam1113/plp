package com.igate.eshop.entity;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/*****************************************************************
 * @author bv815844
 *Package:com.igate.eshop.entity
 *Class Name:Product
 *Description:This is a POJO class which provides getters and setters for Product
 ******************************************************************/
@Component("product")
public class Product {

	private String productId;

	@NotEmpty
	@Size(max=50)
	private String productName;

	@NotEmpty
	@Size(max=100)
	private String productDescription;

	@NotEmpty
	private String productSubCategory;

	@NotEmpty
	@Pattern(regexp="[0-9]{1,6}./?[0-9]{1,2}|[0-9]{1,6}")
	private String productPrice;

	@NotEmpty
	@Pattern(regexp="[0-9]*")
	private String quantity;

	@Autowired
	private ProductImage productImage;

	/****************************************************************** 
	 * Getter and Setter Methods for Product
	 ******************************************************************/


	public ProductImage getProductImage() {
		return productImage;
	}
	public void setProductImage(ProductImage productImage) {
		this.productImage = productImage;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getProductSubCategory() {
		return productSubCategory;
	}
	public void setProductSubCategory(String productCategory) {
		this.productSubCategory = productCategory;
	}
	public String getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
}


