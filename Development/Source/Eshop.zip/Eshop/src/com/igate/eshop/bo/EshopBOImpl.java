package com.igate.eshop.bo;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.igate.eshop.dao.EshopDAOInterface;
import com.igate.eshop.entity.Customer;
import com.igate.eshop.entity.Order;
import com.igate.eshop.entity.Product;
import com.igate.eshop.entity.ProductImage;
import com.igate.eshop.entity.SubCategory;
import com.igate.eshop.entity.User;
import com.igate.eshop.entity.UserCredentials;

/*****************************************************************************************************************************
 * File Name:	EshopBOImpl
 * Package Name:	com.igate.eshop.bo
 * Description:	Implementation class of service layer which interacts with the data access layer and performs the appropriate operations.
 * Version:		1.0
 * Restrictions:	N/A
 * @author 	aa815803,mk815850,ss815801,ns815843,bv815844,nm815851,kp815871
 * Date:		24/12/2013	
 ********************************************************************************************************************************/
@Component("bo")
public class EshopBOImpl implements EshopBOInterface
{

	//Reference variable of dao
	@Autowired
	EshopDAOInterface dao;

	List<Order> orderList=null;


	/****************************************************************************************************************************
	 * Method Name:	getProductDetails
	 * Description:	Calls the getProductDetails method of the data access layer and returns the result to the EshopController.
	 * Return Type:	Object(Product) 
	 * @param:	String productId
	 ****************************************************************************************************************************/
	@Override
	public Product getProductDetails(String productId) 
	{
		Product product=dao.getProductDetails(productId);
		return product;
	}


	/*****************************************************************************************************
	 * Method Name:	getProductDetailsByCategory
	 * Description:	Calls the getProductDetailsByCategory method of the data access layer and returns the result to the EshopController.
	 * Return Type:	List(Product)
	 * @param:	String subCategoryName
	 *****************************************************************************************************/
	@Override
	public List<Product> getProductDetailsByCategory(String subCategoryName) 
	{
		List<Product> productList=dao.getProductDetailsByCategory(subCategoryName);
		return productList;
	}


	/*****************************************************************************************************
	 * Method Name:	getProductDetailsList() 
	 * Description:	Calls the getProductDetailsList method of the data access layer and returns the result to the EshopController.
	 * Return Type:	List(Product)
	 *****************************************************************************************************/
	@Override
	public List<Product> getProductDetailsList() 
	{
		List<Product> productList=dao.getProductDetailsList();
		return productList;
	}

	/*****************************************************************************************************
	 * Method Name:	returnNavigationBarData
	 * Description:	Calls the returnNavigationBarData method of the data access layer and returns the result to the EshopController.
	 * Return Type:	String 
	 *****************************************************************************************************/
	@Override
	public Map<String, List<String>> returnNavigationBarData() 
	{
		Map<String,List<String>> categoryMap=dao.returnNavigationBarData();
		return categoryMap;
	}


	/**************************************************************************************************
	 *Method Name: 	isValidUser
	 *Description:	Calls the isValidUser method of the data access layer and returns the result to the EshopController.
	 *Return Type:	int
	 *@param:	User user
	 *************************************************************************************************/
	@Override
	public int isValidUser(User user)
	{
		int validUser=dao.isValidUser(user);
		return validUser;
	}

	/***************************************************************************************************
	 *Method Name:	searchUser
	 *Description:	Calls the searchUser method of the data access layer and returns the result to the EshopController.
	 *Return Type:	Object (User)
	 *@param: 	User user
	 *************************************************************************************************/
	@Override
	public User searchUser(User user)
	{
		User user1=dao.searchUser(user);
		return user1;
	}

	/************************************************************************************************
	 * Method Name:	registerUser
	 * Description:	Calls the registerUser method of the data access layer and returns the result to the EshopController.
	 * Return Type:	int
	 * @param:	Customer customer
	 **************************************************************************************************/
	@Override
	public int registerUser (Customer customer)
	{
		int valid=dao.registerUser(customer);
		return valid;
	}

	/*****************************************************************************************************
	 * Method Name:	getProductDetailsByName()
	 * Description:	Calls the getProductDetailsByName method of the data access layer and returns the result to the EshopController.
	 * Return Type:	List(Product)
	 * @param: 	String productName
	 *****************************************************************************************************/
	@Override
	public List<Product> getProductDetailsByName(String productName) 
	{
		List<Product> productList=dao.getProductDetailsByName(productName);
		return productList;
	}

	/*****************************************************************************************************
	 * Method Name:	getOrderList
	 * Description:	Calls the getOrderList method of the data access layer and returns the result to the EshopController.
	 * Return Type:	List(Order)
	 * @param:	int value, Date fromDate,Date toDate
	 *****************************************************************************************************/
	@Override
	public List<Order> getOrderList(int value, Date fromDate,Date toDate)
	{
		orderList=dao.getOrderList(value,fromDate,toDate);
		return orderList;
	}

	/*****************************************************************************************************
	 * Method Name:	updateProduct
	 * Description:	Validates the image to be updated first. If the image is valid,calls the
			updateProduct method of data access layer and returns the number of rows updated
			to the controller.
	 * Return Type:	int
	 * @param:	Product product,String updateImage
	 *****************************************************************************************************/
	@Override
	public int updateProduct(Product product, String updateImage) 
	{
		int rowsUpdated=0;
		if(isValidFile(updateImage))
		{
			ProductImage productImage=new  ProductImage();
			productImage.setProductId(product.getProductId());
			productImage.setImage(updateImage);
			product.setProductImage(productImage);
			rowsUpdated=dao.updateProduct(product);	
		}
		else
		{
			rowsUpdated=2;
		}
		return rowsUpdated;
	}

	/*****************************************************************************************************
	 * Method Name:	isValidFile
	 * Description:	Validates the uploaded file format, and returns the result as boolean value and returns the result to the EshopController.
	 * Return Type:	boolean
	 * @param 	String updateImage
	 *****************************************************************************************************/
	@Override
	public boolean isValidFile(String updateImage)
	{

		Pattern pattern=Pattern.compile("([^\\s]+(\\.(?i)(jpg|png|jpeg|gif)))");
		Matcher matcher=pattern.matcher(updateImage);
		return matcher.matches();
	}

	/*****************************************************************************************************
	 * Method Name:	getSubCategories
	 * Description:	Calls the getSubCategories method of data access layer to get a list
	  		of sub-categories and returns this list to controller.
	 * Return Type: 	List(SubCategory)
	 *****************************************************************************************************/
	@Override
	public List<SubCategory> getSubCategories() 
	{
		List<SubCategory> subCategoryList=dao.getSubCategories();
		return subCategoryList;
	}

	/**************************************************************************************************************
	 * Method Name:	addProduct
	 * Description:	Calls addProduct method of the data access layer and returns the result to the EshopController.
	 * Return Type:	int
	 * @param:	Product product
	 **************************************************************************************************************/
	@Override
	public int addProduct(Product product)
	{
		int count=dao.addProduct(product);
		return count;
	}

	/******************************************************************************************************
	 * Method Name:	insertOrderDetails
	 * Description:	Calls insertOrderDetails method of the data access layer and returns the result to the EshopController.
	 * Return Type:	boolean
	 * @param:	List<Product> cartList, double total, String userId
	 *******************************************************************************************************/
	@Override
	public boolean insertOrderDetails(List<Product> cartList, double total, String userId)  
	{
		boolean flag=false;
		flag=dao.insertOrderDetails(cartList, total, userId);
		return flag;
	}

	/************************************************************************************************
	 * Method Name:	isValidUser
	 * Description:	Calls isValidUser method of the data access layer and returns the result to the EshopController.
	 * Return type:	int
	 * @param:	UserCredentials user
	 ********************************************************************************************/
	@Override
	public int isValidUser(UserCredentials user) 
	{
		int UserPresent=(int) dao.isValidUser(user);
		return UserPresent;
	}

	/************************************************************************************************
	 * Method Name:	changePassword
	 * Description:	Calls changePassword method of the data access layer and returns the result to the EshopController.
	 * Return type:	int 
	 * @param:	UserCredentials user
	 ************************************************************************************************/
	@Override
	public int changePassword(UserCredentials user)
	{
		int count=dao.changePassword(user);
		return count;
	}

	/************************************************************************************************
	 * Method Name:	isUserExists
	 * Description:	Checks id username already exists before registering
	 * Return type:	int 
	 * @param:	User user
	 ************************************************************************************************/
	@Override
	public int isUserExists(User user) 
	{
		int count=dao.isUserExists(user);
		return count;
	}
}
