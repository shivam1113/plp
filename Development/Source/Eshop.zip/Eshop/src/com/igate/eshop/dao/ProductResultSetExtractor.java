package com.igate.eshop.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.igate.eshop.entity.Product;
import com.igate.eshop.entity.ProductImage;


/*****************************************************************************************************************************
 * File Name:	ProductResultSetExtractor
 * Package Name:	com.igate.eshop.dao
 * Description:	Retrieves the ProductDetail from the database and sets the values to the Product Bean
 * Version: 	1.0
 * Restrictions:	N/A
 * @author 	aa815803,mk815850,ss815801,ns815843,bv815844,nm815851,kp815871
 * Date:		24/12/2013
 ********************************************************************************************************************************/

@SuppressWarnings("unchecked")
public class ProductResultSetExtractor implements ResultSetExtractor
{
	public Object extractData(ResultSet rs) throws SQLException,DataAccessException 
	{
		Product product=new Product();
		ProductImage productImage=new ProductImage();
		product.setProductId(rs.getString(1));
		product.setProductName(rs.getString(2));
		product.setProductDescription(rs.getString(3));
		product.setProductPrice(rs.getDouble(4)+"");
		product.setQuantity(rs.getInt(5)+"");
		productImage.setProductId(rs.getString(1));
		productImage.setImage(rs.getString(6));
		product.setProductImage(productImage);
		return product;	
	}
}
