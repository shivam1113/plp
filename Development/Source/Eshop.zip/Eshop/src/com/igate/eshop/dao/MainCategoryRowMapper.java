package com.igate.eshop.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


/*****************************************************************************************************************************
 * File Name:	MainCategoryRowMapper 
 * Package Name:	com.igate.eshop.dao
 * Description:	Maps the values of the ResultSet and sets them to the MainCategory List
 * Version: 	1.0
 * Restrictions:	N/A
 * @author 	aa815803,mk815850,ss815801,ns815843,bv815844,nm815851,kp815871
 * Date:		24/12/2013
 ********************************************************************************************************************************/

public class MainCategoryRowMapper implements RowMapper<String> 
{

	@Override
	public String mapRow(ResultSet rs, int line) throws SQLException 
	{
		MainCategoryResultSetExtractor extractor = new MainCategoryResultSetExtractor();
		String mainCategory= extractor.extractData(rs);
		return  mainCategory;
	}

}
