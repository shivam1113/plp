package com.igate.eshop.entity;

import java.util.Date;

/***************************************************************************************************************
 * File Name:	Order
 * Package Name:	com.igate.eshop.entity
 * Description:	Consists of all the properties that are required for placing an Order for the Product such as orderId,productId,
		customerid,orderDate,orderStatus,quantity and totalPrice.
 * Version: 	1.0
 * Restrictions:	N/A
 * @author 	aa815803,mk815850,ss815801,ns815843,bv815844,nm815851,kp815871
 * Date:		24/12/2013
 ****************************************************************************************************************/
public class Order 
{
	private String orderId;
	private String productId;
	private String customerid;
	private Date orderDate;
	private String orderStatus;
	private int quantity;
	private double totalPrice;

	/****************************************************************** 
	 * Getter and Setter Methods for Order
	 ******************************************************************/

	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getCustomerid() {
		return customerid;
	}
	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
}
