package com.igate.eshop.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.stereotype.Component;

import com.igate.eshop.entity.Customer;
import com.igate.eshop.entity.Order;
import com.igate.eshop.entity.Product;
import com.igate.eshop.entity.ProductImage;
import com.igate.eshop.entity.SubCategory;
import com.igate.eshop.entity.User;
import com.igate.eshop.entity.UserCredentials;


/*****************************************************************************************************************************
 * File Name:	EshopDAOImpl
 * Package Name:	com.igate.eshop.dao
 * Description:	Implementation class of data access layer which interacts with the database and performs the appropriate operations.
 * Version: 	1.0
 * Restrictions:	N/A
 * @author 	aa815803,mk815850,ss815801,ns815843,bv815844,nm815851,kp815871
 * Date:		24/12/2013
 ********************************************************************************************************************************/
@Component("dao")
public class EshopDAOImpl implements EshopDAOInterface
{

	//Reference variable of simpleJdbctemplate
	@Autowired
	SimpleJdbcTemplate simpleJdbcTemplate;

	//Database Queries
	private static final String UPDATE_PASSWORD="UPDATE User_Details_team1 SET password=? WHERE USER_ID=? AND PASSWORD=?";
	private static final String RETRIVE_PRODUCT_DETAILS_BY_ID="SELECT P.product_id,P.product_name,P.product_description,P.product_price,P.quantity,PI.image FROM Product P JOIN Product_Image PI ON P.product_id=PI.product_id WHERE P.product_id=?";
	private static final String RETRIVE_PRODUCT_DETAILS_BY_SUBCATEGORY="SELECT P.product_id,P.product_name,P.product_description,P.product_price,P.quantity,PI.image FROM Product P JOIN Product_Image PI ON P.product_id=PI.product_id WHERE P.Product_Sub_Category=?";
	private static final String RETRIVE_ALL_PRODUCT_DETAILS="SELECT P.product_id,P.product_name,P.product_description,P.product_price,P.quantity,PI.image FROM Product P JOIN Product_Image PI ON P.product_id=PI.product_id";
	private static final String RETRIVE_MAIN_CATEGORIES="SELECT category_name FROM Category"; 
	private static final String CHECK_USER_BY_ID_AND_PASSWORD="SELECT count(role) FROM user_details_team1  WHERE user_id=? AND password=?";
	private static final String RETRIEVE_ROLE_BY_ID_AND_PASSWORD="SELECT role FROM user_details_team1 WHERE user_id=? AND password=?";
	private static final String INSERT_INTO_USERDETAILS="INSERT INTO user_details_team1 VALUES(?,?,?)";
	private static final String INSERT_INTO_CUSTOMER="INSERT INTO Customer VALUES(?,?,?,?,?)";
	private static final String RETRIVE_PRODUCT_DETAILS_BY_NAME="SELECT P.product_id,P.product_name,P.product_description,P.product_price,P.quantity,PI.image FROM Product P JOIN Product_Image PI ON P.product_id=PI.product_id WHERE UPPER(P.product_name) LIKE ?";	
	private static final String RETRIVE_ALL_ORDER_DETAILS="SELECT order_id,product_id,customer_id,order_date,order_status,total_price,quantity FROM order_details"; 
	private static final String RETRIVE_ORDER_DETAILS_BY_STATUS="SELECT order_id,product_id,customer_id,order_date,order_status,total_price,quantity FROM order_details WHERE order_status='Pending' ";
	private static final String RETRIVE_ORDER_DETAILS_BETWEEN_DATES="SELECT order_id,product_id,customer_id,order_date,order_status,total_price,quantity FROM order_details WHERE order_date BETWEEN ? AND ?";
	private static final String UPDATE_PRODUCT_WITHOUT_IMAGE="UPDATE product SET product_name=?,product_description=?,product_price=?,quantity=?,product_sub_category=? WHERE product_id=?";
	private static final String UPDATE_PRODUCT_IMAGE="UPDATE product_image SET image=? WHERE product_id=?";
	private static final String RETRIEVE_SUB_CATEGORY_LIST="SELECT sub_category_name,category_name FROM sub_category";
	private static final String RETREIVE_PRODUCTSEQUENCE="SELECT product_id_sequence.NEXTVAL FROM DUAL";
	private static final String INSERT_PRODUCTDETAILS="INSERT INTO product VALUES(?,?,?,?,?,?)";
	private static final String INSERT_PRODUCTIMAGE="INSERT INTO product_image VALUES(?,?)";
	private static final String RETREIVE_ORDERSEQUENCE="SELECT order_details_id_sequence.NEXTVAL FROM DUAL";
	private static final String INSERT_ORDERDETAILS="INSERT INTO order_details VALUES(?,?,?,?,?,?,?)";
	private static final String CHECK_IF_USER_EXISTS="SELECT count(role) FROM user_details_team1 WHERE user_id=?";


	List<Order> eList=new ArrayList<Order>();
	static Logger myLogger=null;

	public EshopDAOImpl() 
	{
		myLogger=Logger.getLogger("LoggingInterceptor.class");
	}

	/****************************************************************************************************************************
	 * Method Name:	getProductDetails
	 * Description:	Retrives details of the given product from the database and returns the data to the service layer. 
	 * Return Type:	Object(Product) 
	 * @param:	String productId
	 ****************************************************************************************************************************/

	@SuppressWarnings("unchecked")
	@Override
	public Product getProductDetails(String productId) 
	{
		RowMapper mapper = new RowMapper() 
		{
			@Override
			public Object mapRow(ResultSet rs, int row) throws SQLException 
			{
				Product product=new Product();
				ProductImage productImage=new ProductImage();
				product.setProductId(rs.getString(1));
				product.setProductName(rs.getString(2));
				product.setProductDescription(rs.getString(3));
				product.setProductPrice(rs.getDouble(4)+"");
				product.setQuantity(rs.getInt(5)+"");
				productImage.setProductId(rs.getString(1));
				productImage.setImage(rs.getString(6));
				product.setProductImage(productImage);
				return product;
			}
		};
		Product product= (Product) simpleJdbcTemplate.queryForObject(RETRIVE_PRODUCT_DETAILS_BY_ID,mapper,productId);
		return product;
	}

	/******************************************************************************************************************
	 * Method Name:	getProductDetailsByCategory
	 * Description:	Retrives details of all the products for the given SubCategory from the database and returns the data to the service layer.
	 * Return Type:	List(Product)
	 * @param:	String subCategoryName
	 ********************************************************************************************************************/

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getProductDetailsByCategory(String subCategoryName) 
	{
		List<Product> productList=simpleJdbcTemplate.query(RETRIVE_PRODUCT_DETAILS_BY_SUBCATEGORY,new ProductRowMapper(),subCategoryName);
		myLogger.info(RETRIVE_PRODUCT_DETAILS_BY_SUBCATEGORY);
		return productList;
	}

	/*****************************************************************************************************
	 * Method Name:	getProductDetailsList() 
	 * Description:	Retrives details of all the products from the database and returns the data to the service layer.
	 * Return Type:	List(Product)
	 *****************************************************************************************************/
	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getProductDetailsList() 
	{
		return simpleJdbcTemplate.query(RETRIVE_ALL_PRODUCT_DETAILS,new ProductRowMapper());
	}

	/*****************************************************************************************************************
	 * Method Name:	returnNavigationBarData
	 * Description:	Retrives data like categories and products to be displayed on the home screen and returns tha data to the service layer.
	 * Return Type:	String 
	 ************************************************************************************************************/
	@Override
	public Map<String, List<String>> returnNavigationBarData() 
	{
		List<String> mainCategory=simpleJdbcTemplate.query(RETRIVE_MAIN_CATEGORIES,new MainCategoryRowMapper());
		List<SubCategory> subCategoryList =getSubCategories();
		Map<String,List<String>> categoryMap=new HashMap<String,List<String>>();
		String SubCategoryName;
		List<String> subCategory=null;
		int categorySize=mainCategory.size();
		for(int mainIndex=0;mainIndex<categorySize;mainIndex++)
		{
			String categoryName=mainCategory.get(mainIndex);
			subCategory=new ArrayList<String>();
			for(int subIndex=0;subIndex<subCategoryList.size();subIndex++)
			{
				SubCategory subCategoryObj=subCategoryList.get(subIndex);
				String  categoryNameSub=subCategoryObj.getCategory();
				if(categoryName.equals(categoryNameSub))
				{
					SubCategoryName=subCategoryObj.getSubCategoryName();
					subCategory.add(SubCategoryName);
				}
			}
			categoryMap.put(categoryName, subCategory);
		}
		return categoryMap;
	}


	/************************************************************************************************************************************
	 * Method Name:	getSubCategories
	 * Description:	Retrives list of all subCategories from the database and returns the data to the service layer. 
	 * Return Type:	List(SubCategory) 
	 * @param:	String productId
	 ************************************************************************************************************************************/
	@SuppressWarnings("unchecked")
	@Override
	public List<SubCategory> getSubCategories()    
	{
		List<SubCategory> subCategoryList=simpleJdbcTemplate.query(RETRIEVE_SUB_CATEGORY_LIST,new SubCategoryRowMapper());
		return subCategoryList;
	}


	/**************************************************************************************************************
	 *Method Name: 	isValidUser
	 *Description:	Validates the User By UserId and Password and returns the result to the service layer
	 *Return Type:	int
	 *@param:	User user
	 ******************************************************************************************************************/
	@Override
	public int isValidUser(User user)
	{
		Object[] params=new Object[]{user.getUserId(),user.getPassword()};
		int count=(int)simpleJdbcTemplate.queryForInt(CHECK_USER_BY_ID_AND_PASSWORD,params);
		return count;
	}

	/*********************************************************************************************************
	 *Method Name:	 searchUser
	 *Description:	Searches the User from the database based on the role and returns the result to the service layer.
	 *Return Type:	Object (User)
	 *@param: 	User user
	 ***********************************************************************************************************/
	@Override
	@SuppressWarnings("unchecked")
	public User searchUser(User user)
	{
		RowMapper mapper = new RowMapper()
		{
			public User mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				User user = new User();
				user.setRole(rs.getString(1));
				return user;
			}
		};
		User user1=(User) simpleJdbcTemplate.queryForObject(RETRIEVE_ROLE_BY_ID_AND_PASSWORD, mapper, user.getUserId(), user.getPassword());
		return user1;
	}

	/**********************************************************************************************
	 * Method Name:	registerUser
	 * Description:	Registers NewUser with all valid UserCredentials and returns the result to the service layer
	 * Return Type:	int
	 * @param:	Customer customer
	 ***************************************************************************************************/
	@Override
	public int registerUser(Customer customer)
	{  
		int status=0;
		Object[] params1=new Object[]{customer.getUserId(), customer.getPassword(), customer.getRole()};
		int user= simpleJdbcTemplate.update(INSERT_INTO_USERDETAILS,params1);

		Object[] params=new Object[]{customer.getUserId(),customer.getCustomerName(), customer.getCustomerEmailId(), customer.getCustomerCity(),customer.getCustomerMobileNo()};
		int customerInsert= simpleJdbcTemplate.update(INSERT_INTO_CUSTOMER,params);

		if(customerInsert==1 && user==1)
		{
			status=1;
		}
		else
		{
			status=0;
		}
		return status;
	}


	/*****************************************************************************************************
	 * Method Name:	getProductDetailsByName()
	 * Description:	Retrives details of all the products from the database having similar product names and returns the 
			result to the service layer.
	 * Return Type:	List(Product)
	 * @param: 	String productName
	 *****************************************************************************************************/
	@Override
	@SuppressWarnings("unchecked")
	public List<Product> getProductDetailsByName(String productName)
	{
		List<Product> productList=null;
		String name="%"+productName.toUpperCase()+"%";
		productList=simpleJdbcTemplate.query(RETRIVE_PRODUCT_DETAILS_BY_NAME,new ProductRowMapper(),name);
		return productList;
	}



	/*****************************************************************************************************
	 * Method Name:	getOrderList
	 * Description:	Retrives details of the order from the database based on choices
				   value==1 : retrieves details of all orders placed till date.
				   value==2 : retrieves details of orders placed whose status is 'pending'
	 			   value==3 : retrieves details of orders placed between the two dates
			and returns the result to the service layer.
	 * Return Type:	List(Order)
	 * @param:	int value, Date fromDate,Date toDate
	 *****************************************************************************************************/
	@SuppressWarnings("unchecked")
	@Override
	public List<Order> getOrderList(int value, Date fromDate,Date toDate) 
	{

		if(value==1)
		{
			eList =simpleJdbcTemplate.query(RETRIVE_ALL_ORDER_DETAILS,new OrderRowMapper());

		}
		else if(value==2)
		{
			eList =simpleJdbcTemplate.query(RETRIVE_ORDER_DETAILS_BY_STATUS,new OrderRowMapper());
		}
		else if(value==3)
		{
			Object[] params=new Object[]{new java.sql.Date(fromDate.getTime()),new java.sql.Date(toDate.getTime())};
			eList=simpleJdbcTemplate.query(RETRIVE_ORDER_DETAILS_BETWEEN_DATES, new OrderRowMapper(), params);
		}
		return eList;
	}

	/*****************************************************************************************************
	 * Method Name:	updateProduct
	 * Description:	Performs update operation by updating the details of a product and its corresponding image
		 	according to the product ID in the database and returns the result to the service layer.
	 * Return Type:	int
	 * @param:	Product product
	 *****************************************************************************************************/
	@Override
	public int updateProduct(Product product) 
	{

		int updateWithoutImage=0;
		int updateProductCount=0;
		Object[] params1 = new Object[]{product.getProductName(),product.getProductDescription(),Double.parseDouble(product.getProductPrice()),Integer.parseInt(product.getQuantity()),product.getProductSubCategory(),product.getProductId()};
		updateWithoutImage=simpleJdbcTemplate.update(UPDATE_PRODUCT_WITHOUT_IMAGE, params1);
		if(updateWithoutImage>0)
		{
			Object[] params2 = new Object[]{product.getProductImage().getImage(),product.getProductId()};
			updateProductCount=simpleJdbcTemplate.update(UPDATE_PRODUCT_IMAGE, params2);
		}
		return updateProductCount;  
	}

	/**************************************************************************************************************
	 * Method Name:	addProduct
	 * Description:	Adds the Product and its details into the database and returns the result to the service layer.
	 * Return Type:	int
	 * @param:	Product product
	 **************************************************************************************************************/
	@Override
	public int addProduct(Product product)
	{
		String productId=(String)simpleJdbcTemplate.queryForObject(RETREIVE_PRODUCTSEQUENCE,String.class);
		int noOfRows=0;
		Object[] params=new Object[]{productId,product.getProductName(),product.getProductDescription(),product.getProductSubCategory(),product.getProductPrice(),product.getQuantity()};
		if(simpleJdbcTemplate.update(INSERT_PRODUCTDETAILS,params)>0)
		{  
			Object[] params2=new Object[]{productId,product.getProductImage().getImage()};
			noOfRows= simpleJdbcTemplate.update(INSERT_PRODUCTIMAGE, params2);
		}
		return noOfRows;
	}


	/****************************************************************************************************************************
	 * Method Name:	insertOrderDetails
	 * Description:	Inserts order details for the products into the database and returns the result to the service layer.
	 * Return Type:	boolean
	 * @param:	List<Product> cartList, double total, String userId
	 ****************************************************************************************************************************/
	@Override
	public boolean insertOrderDetails(List<Product> cartList, double total, String userId)  
	{

		Boolean flag=false;
		int noOfRows=0;
		Object[] params;
		for(Product product:cartList)
		{
			String orderId=(String)simpleJdbcTemplate.queryForObject(RETREIVE_ORDERSEQUENCE,String.class);
			params=new Object[]{orderId,product.getProductId(),userId,new java.sql.Date(new java.util.Date().getTime()),"Pending",total,product.getQuantity()};
			noOfRows=simpleJdbcTemplate.update(INSERT_ORDERDETAILS,params);
			if(noOfRows>0)
			{
				flag=true;
			}
		}
		return flag;
	}


	/****************************************************************************************************************
	 * Method Name:	isValidUser
	 * Description:	Validates the user from the database based on UserId and Password and returns the result to the service layer.
	 * Return type:	int
	 * @param:	UserCredentials user
	 *******************************************************************************************************************/
	public int isValidUser(UserCredentials user) 

	{

		Object[]params=new Object[]{user.getUserId(),user.getPassword()};
		int count=0;
		count=(int)simpleJdbcTemplate.queryForInt(CHECK_USER_BY_ID_AND_PASSWORD,params);
		return count;
	}

	/*******************************************************************************************************************
	 * Method Name:	changePassword
	 * Description:	Updates the New Password into the database based on UserId and Password and returns the result to the service layer.
	 * Return type:	int 
	 * @param:	UserCredentials user
	 **************************************************************************************************************/
	@Override
	public int changePassword(UserCredentials user) 

	{
		Object[] params=new Object[]{user.getNewPassword(),user.getUserId(),user.getPassword()};
		return simpleJdbcTemplate.update(UPDATE_PASSWORD, params);


	}

	/****************************************************************************************************************
	 * Method Name:	isUserExists
	 * Description:	Validates the user from the database based on UserId  and returns the result to the service layer.
	 * Return type:	int
	 * @param:	UserCredentials user
	 *******************************************************************************************************************/
	@Override
	public int isUserExists(User user) 
	{
		Object[]params=new Object[]{user.getUserId()};
		int count=0;
		count=(int)simpleJdbcTemplate.queryForInt(CHECK_IF_USER_EXISTS,params);
		return count;
	}

}
