package com.igate.eshop.entity;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;


/*****************************************************************
 * @author bv815844
 *Package:com.igate.eshop.entity
 *Class Name:ProductImage
 *Description:This is a POJO class which provides getters and setters for Product Image
 ******************************************************************/

@Component("productImage")
public class ProductImage {

	private String productId;

	@NotEmpty
	private String image;


	/****************************************************************** 
	 * Getter and Setter Methods for ProductImage
	 ******************************************************************/

	public String getProductId()
	{
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
}
