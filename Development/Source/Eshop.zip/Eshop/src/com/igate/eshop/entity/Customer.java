package com.igate.eshop.entity;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

/*****************************************************************
 * @author bv815844
 *Package:com.igate.eshop.entity
 *Class Name:Customer
 *Description:This is a POJO class which provides getters and setters for Customer
 ******************************************************************/
@Component("customer")
public class Customer 
{
	@NotEmpty
	@Pattern(regexp ="[0-9a-zA-Z]*")
	@Size(max = 10) 
	private String userId;

	@NotEmpty
	@Size(max = 16) 
	private String password;

	@NotEmpty
	@Pattern(regexp ="[a-zA-Z  ]*")
	@Size(max = 30) 
	private String customerName;

	private String customerCity;

	@NotEmpty
	//@Pattern(regexp ="[A-Za-z0-9]+@[A-Za-z0-9.-]+[.][A-Za-z]{2,4}")
	@Email
	private String customerEmailId;

	@NotEmpty
	@Size(max=10)
	@Pattern(regexp="[0-9]{10}")
	private String customerMobileNo;

	@NotEmpty
	@Size(max = 16) 
	private String confirmPassword;

	private String role;

	/****************************************************************** 
	 * Getter and Setter Methods for Customer
	 ******************************************************************/

	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getUserId() 
	{
		return userId;
	}
	public void setUserId(String userId) 
	{
		this.userId = userId;
	}
	public String getPassword()
	{
		return password;
	}
	public void setPassword(String password)
	{
		this.password = password;
	}

	public String getCustomerName()
	{
		return customerName;
	}

	public void setCustomerName(String customerName)
	{
		this.customerName = customerName;
	}

	public String getCustomerCity() 
	{
		return customerCity;
	}

	public void setCustomerCity(String customerCity)
	{
		this.customerCity = customerCity;
	}

	public String getCustomerEmailId()
	{
		return customerEmailId;
	}

	public void setCustomerEmailId(String customerEmailId)
	{
		this.customerEmailId = customerEmailId;
	}

	public String getCustomerMobileNo() 
	{
		return customerMobileNo;
	}

	public void setCustomerMobileNo(String customerMobileNo)
	{
		this.customerMobileNo = customerMobileNo;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
}
