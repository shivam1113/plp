package com.igate.eshop.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;


/*****************************************************************************************************************************
 * File Name:	MainCategoryResultSetExtractor
 * Package Name:	com.igate.eshop.dao
 * Description:	Retrieves the MainCategories of the Product from the database and sets the values to the MainCategory List
 * Version: 	1.0
 * Restrictions:	N/A
 * @author 	aa815803,mk815850,ss815801,ns815843,bv815844,nm815851,kp815871
 * Date:		24/12/2013
 ********************************************************************************************************************************/

public class MainCategoryResultSetExtractor implements ResultSetExtractor<String>
{

	@Override
	public String extractData(ResultSet rs) throws SQLException,DataAccessException 
	{
		return rs.getString(1);
	}

}
