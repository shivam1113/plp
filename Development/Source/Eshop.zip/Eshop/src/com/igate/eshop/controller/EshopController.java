package com.igate.eshop.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.igate.eshop.bo.EshopBOInterface;
import com.igate.eshop.entity.Customer;
import com.igate.eshop.entity.Order;
import com.igate.eshop.entity.Product;
import com.igate.eshop.entity.ProductImage;
import com.igate.eshop.entity.SubCategory;
import com.igate.eshop.entity.User;
import com.igate.eshop.entity.UserCredentials;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

/*****************************************************************************************************************************
 * File Name:EshopController
 * Package Name:com.igate.eshop.controller
 * Description:	Controller which handles the user request and navigate to respective jsp pages.
 * Version: 	1.0
 * Restrictions:N/A
 * @author 	aa815803,mk815850,ss815801,ns815843,bv815844,nm815851,kp815871
 * Date:		24/12/2013
 ********************************************************************************************************************************/
@Controller
@Scope("session")
public class EshopController 
{

	@Autowired
	EshopBOInterface bo;

	@Autowired
	private HttpSession session;

	@Autowired
	Product product;

	@Autowired
	ProductImage productImage;

	List<String> categoryList=new ArrayList<String>();
	List<SubCategory> subCategoryList=new ArrayList<SubCategory>();

	Map<String,List<String>> categoryMap=new HashMap<String,List<String>>();
	List<Product> listProductDetails=new ArrayList<Product>();
	List<Product> cartList=new ArrayList<Product>();
	List<Order> orderList=new ArrayList<Order>();
	Date fromDate=new Date();
	Date toDate=new Date();
	User user=new User();
	String errorMsg;
	int value;




	/************************************************************************************************************************************
	 * Method Name:prepareLogin
	 * Description:This method will bind User Object and navigate the user to the Eshop_User_Login page.
	 * Return Type:String 
	 * @param:model:Model model
	 ***********************************************************************************************************************************/
	@RequestMapping(value="prepareLoginPage")
	public String prepareLogin(Model model)
	{
		model.addAttribute("User",new User());
		return "Eshop_User_Login";
	}


	/************************************************************************************************************************************
	 * Method Name:loginDivert
	 * Description:This method will navigate the user to the Eshop_User_Login page.
	 * Return Type:String 
	 * @param:Model model
	 ***********************************************************************************************************************************/
	@RequestMapping(value="loginDivert")
	public String loginDivert(Model model)
	{
		model.addAttribute("User",new User());
		return "Eshop_User_Login";
	}



	/************************************************************************************************************************************
	 * Method Name:checkLogin
	 * Description:Validates User Credentials and determines the role of the user and navigates to the respective page.
	 * 	      The role of the user are as follows:
	 *		1.Customer will be navigated to Eshop_Customer_HomePage where he/she can view the items.
	 *		2.Sales Manager will be navigated to Eshop_SalesManager_ViewReports where he/she can view the 
	 *		   sales reports.
	 *		3.Admin will be navigated to Eshop_Admin_HomePage where he/she can add/update the products
	 *
	 * Return Type:String 
	 * @param:@ModelAttribute(value="User") @Valid User user
	 * @param:BindingResult result
 	 * @param:Model model
	 ***********************************************************************************************************************************/
	@RequestMapping(value="checkLogin")
	public String checkLogin(@ModelAttribute(value="User") @Valid User user,BindingResult result,Model model)
	{

		String page= "Eshop_User_Login";
		if(result.hasErrors())
		{
			return "Eshop_User_Login";
		}
		else 
		{
			try
			{
				int exists=bo.isValidUser(user);
				if(exists!=0)  
				{
					User user1=bo.searchUser(user);
					String roles=user1.getRole();

					//checks for admin role
					if ("admin".equals(roles)) 
					{
						session.setAttribute("isLogged","admin");
						page="Eshop_Admin_HomePage";
					} 

					//checks for salesManager role
					else if ("sales manager".equals(roles))
					{
						session.setAttribute("isLogged","SalesManager");
						page="Eshop_SalesManager_ViewReports";
					} 

					//checks for customer role
					else if ("customer".equals(roles)) 
					{
						session.setAttribute("isLogged",user.getUserId());
						page="Eshop_Customer_HomePage";
					}
				}
				else
				{
					model.addAttribute("User",new User());
					model.addAttribute("LoginMsg","Invalid UserName/Password");
				}

			}
			catch( DataAccessException e)
			{
				model.addAttribute("errorMessage",e.getMessage());
				page="Eshop_User_ErrorPage";
			}
		}
		return page;
	}


	/*****************************************************************************************************************************************
	 * Method Name:prepareRegister
	 * Description:The user is navigated to the Eshop_Customer_Register page where he/she can register himself/herself
	 * Return Type:String 
	 * @param:Model model
	 ****************************************************************************************************************************************/
	@RequestMapping(value="prepareRegisterPage")
	public String prepareRegister(Model model)
	{
		model.addAttribute("customer",new Customer());
		return "Eshop_Customer_Register";
	}


	/************************************************************************************************************************************
	 * Method Name:checkRegister
	 * Description:Retrieves all the details of the registration form and inserts into the database.
	 * Return Type:String 
	 * @param:@ModelAttribute("customer") @Valid Customer customer
	 * @param:BindingResult result
	 * @param:Model model
	 ***********************************************************************************************************************************/
	@RequestMapping(value="checkRegistration")
	public String checkRegister(@ModelAttribute("customer") @Valid Customer customer , BindingResult result,Model model)
	{
		String target="";
		if(result.hasErrors())
		{
			return "Eshop_Customer_Register";
		}
		else 
		{
			try
			{
				user.setUserId(customer.getUserId());
				int count=bo.isUserExists(user);
				if(count!=1)
				{
					if(customer.getPassword()!=null && customer.getConfirmPassword()!=null)
					{
						if(!((customer.getConfirmPassword()).equals(customer.getPassword())))
						{
							model.addAttribute("spanMsg","Password Mismatch");
							target="Eshop_Customer_Register";
						}
						else
						{
							customer.setRole("customer");
							int register=bo.registerUser(customer);
							if(register==1)
							{
								model.addAttribute("User",new User());
								target="Eshop_User_Login";
							}
							else
							{
								model.addAttribute("errorMessage","Unable to Register");
								target="Eshop_User_ErrorPage";
							}
						}
					}
				}
				else
				{
					model.addAttribute("spanMsg","Username already exists please choose some other username");
					target="Eshop_Customer_Register";
				}
			}
			catch(DataAccessException e)
			{
				model.addAttribute("errorMessage",e.toString());
				target="Eshop_User_ErrorPage";
			}
		}
		return target;
	}
	/************************************************************************************************************************************
	* Method Name:prepareHomePage
	* Description:Retrieves data like categories and products to be displayed on the home screen from the database.
	* Return Type:String 
	* @param:Model model
	***********************************************************************************************************************************/
	@RequestMapping(value="index")
	public String prepareHomePage(Model model)
	{

		Logger myLogger=null;
		myLogger=Logger.getLogger("LoggingInterceptor.class");
		myLogger.info("Test");
		try 
		{
			listProductDetails=bo.getProductDetailsList();
		} 
		catch (DataAccessException e) 
		{

			model.addAttribute("errorMessage",e.getMessage());
			return "Eshop_User_ErrorPage";
		}
		try 
		{
			categoryMap=bo.returnNavigationBarData();
		} 
		catch (DataAccessException e) 
		{
			model.addAttribute("errorMessage",e.getMessage());
			return "Eshop_User_ErrorPage";
		}	
		session.setAttribute("productList",listProductDetails);
		session.setAttribute("categoryMap",categoryMap);
		return "Eshop_Customer_HomePage";
	}



	/********************************************************************************************************************************
	 * Method Name:getProductsByCategory
	 * Description:Retrives products as per the selected category.
	 * Return Type:String 
	 * @param:Model model
	 ********************************************************************************************************************************/
	@RequestMapping(value="getProductsByCategory")
	public String getProductsByCategory(@RequestParam(value="categoryName") String subCategoryName, Model model)
	{
		try 
		{
			listProductDetails=bo.getProductDetailsByCategory(subCategoryName);
		} 
		catch (DataAccessException e) 
		{
			model.addAttribute("errorMessage",e.getMessage());
			return "Eshop_User_ErrorPage";
		}
		try 
		{
			categoryMap=bo.returnNavigationBarData();
		} 
		catch (DataAccessException e) 
		{
			model.addAttribute("errorMessage",e.getMessage());
			return "Eshop_User_ErrorPage";		
		}	
		session.setAttribute("productList",listProductDetails);
		session.setAttribute("categoryMap",categoryMap);
		return "Eshop_Customer_HomePage";
	}



	/****************************************************************************************************************************************
	 * Method Name:prepareViewItemPage
	 * Description:Collects data of a single product and sends it to the Eshop_Customer_ViewItem where the detailed data of product is shown.
	 * Return Type:String 
	 * @param productId 
	 * @param:Model model
	 **************************************************************************************************************************************/
	@RequestMapping(value="prepareViewItemPage")
	public String prepareViewItemPage(@RequestParam(value="productId") String productId,@RequestParam(value="buttonValue") String buttonValue, Model model)
	{
		if("View".equals(buttonValue))
		{
			try 
			{

				//System.out.println("Coming in the view Item Page");
				//System.out.println(productId);
				product=bo.getProductDetails(productId);
				model.addAttribute("product",product);
			} 
			catch (DataAccessException e) 
			{
				model.addAttribute("errorMessage",e.getMessage());
				return "Eshop_User_ErrorPage";
			}
			return "Eshop_Customer_ViewItem";
		}
		else
		{
			try
			{
				Product product=new Product();
				product=bo.getProductDetails(productId);
				model.addAttribute("product",product);
				session.setAttribute("update product", product);
				session.setAttribute("image",product.getProductImage().getImage());
				List<SubCategory> subCategoryList=null;

				//get list of sub categories from the database
				subCategoryList=bo.getSubCategories();
				session.setAttribute("subCategoryList",subCategoryList);
			}
			catch (DataAccessException e) 
			{
				model.addAttribute("errorMessage",e.getMessage());
				return "Eshop_User_ErrorPage";
			}
			return "Eshop_Admin_UpdateProduct";
		}
	}




	/****************************************************************************************************************************************************************
	 * Method Name:proceedToAddToCartPage
	 * Description:Adds the selected item into the cart and navigate to Eshop_Customer_AddToCart page.
	 * Return Type:String 
	 * @param:@ModelAttribute(value="product") Product product 
	 * @param:@RequestParam(value="userQuantity") String userQuantity
	 * @param:Model model
	 *********************************************************************************************************************************************************************/
	@RequestMapping(value="proceedToAddToCartPage")
	public String proceedToAddToCartPage(@ModelAttribute(value="product") Product product, @RequestParam(value="userQuantity") String userQuantity,Model model)
	{
		if(session.getAttribute("isLogged")!=null)
		{
			if(!"".equals(userQuantity))
			{
				Pattern pattern;
				Matcher matcher;
				pattern=Pattern.compile("[0-9]");
				matcher=pattern.matcher(userQuantity);
				if(matcher.find())
				{
					int enteredQuantity=Integer.parseInt(userQuantity);
					if(enteredQuantity<=Integer.parseInt(product.getQuantity()) && enteredQuantity>0)
					{
						product.setQuantity(userQuantity);
						cartList.add(product);
						session.setAttribute("cartList", cartList);
						return "Eshop_Customer_AddToCart";
					}
					else
					{
						model.addAttribute("errorMsg","Enter a valid Quantity");
						model.addAttribute("product",product);
						return "Eshop_Customer_ViewItem";
					}
				}
				else
				{
					model.addAttribute("errorMsg","Enter a valid Quantity");
					model.addAttribute("product",product);
					return "Eshop_Customer_ViewItem";
				}
			}
			else
			{
				model.addAttribute("errorMsg","Quantity cannot be null");
				model.addAttribute("product",product);
				return "Eshop_Customer_ViewItem";
			}
		}
		else
		{
			model.addAttribute("User",new User());
			return "Eshop_User_Login";
		}
	}


	/***********************************************************************************************************************************
	 * Method Name:deleteFromCart
	 * Description:Deletes the selected item into the cart and navigate to the same page.
	 * Return Type:String 
	 * @param:Model Object
	 * @param:@RequestParam(value="productId") String productId
	 * @param:Model model
	 ***********************************************************************************************************************************/
	@SuppressWarnings("unchecked")
	@RequestMapping(value="deleteFromCart")
	public String deleteFromCart(@RequestParam(value="productId") String productId,Model model)
	{
		List<Product> removeList=(List)session.getAttribute("cartList");
		Iterator<Product> iterator=removeList.iterator();
		while(iterator.hasNext())
		{
			product=iterator.next();
			String productId2=product.getProductId();
			if(productId2.equals(productId))
			{
				iterator.remove();
				break;
			}
		}
		session.setAttribute("cartList",removeList);
		return "Eshop_Customer_AddToCart";
	}


	/***********************************************************************************************************************************
	 * Method Name:gotoAddToCartPage
	 * Description:Navigate to Cart page whenever customer clicks on to the cart icon.
	 * Return Type:String 
	 * @param:Model Object
	 ***********************************************************************************************************************************/
	@RequestMapping(value="gotoAddToCartPage")
	public String gotoAddToCartPage(Model model)
	{
		return "Eshop_Customer_AddToCart";
	}

	/*****************************************************************************************************
	 * Method Name:searchProductDetails
	 * Description:Retrieves details of all the products from the database having similar product names 
	 * Return Type:String 
	 * @param productName
	 * @param:@RequestParam(value="productName")String productName
	 * @param:Model model
	 *****************************************************************************************************/
	@RequestMapping(value="searchProduct")
	public String searchProductDetails(@RequestParam(value="productName")String productName,Model model)
	{
		List<Product> listProductDetails=new ArrayList<Product>();

		try 
		{
			listProductDetails=bo.getProductDetailsByName(productName);
			session.setAttribute("productList",listProductDetails);
		} 
		catch (DataAccessException e) 
		{
			model.addAttribute("errorMessage",e.getMessage());
			return "Eshop_User_ErrorPage";
		}
		return "Eshop_Customer_HomePage";

	}

	/*****************************************************************************************************
	 * Method Name:prepareView
	 * Description:Prepares the Menu of the SalesPerson.
	 * Return Type:String 
	 * @param @RequestParam(value="name") String mode
	 * @param: Model object
	 * @param: HttpSession object
	 *****************************************************************************************************/


	@RequestMapping(value="/view")
	public String prepareView(@RequestParam(value="name") String mode,Model model,HttpSession session)
	{


		if("viewByDate".equals(mode))
		{
			return "Eshop_SalesManager_RecordsByDate";
		}

		//View reports By Status
		else if("viewByStatus".equals(mode))
		{
			value=2;
			try 
			{
				orderList=(ArrayList<Order>) bo.getOrderList(value,fromDate,toDate);
				if(orderList!=null)
				{

					model.addAttribute("condition",true);
					session.setAttribute("orderList",orderList);
				}

			}
			catch (DataAccessException e) 
			{
				model.addAttribute("errorMessage",e.getMessage());
				return "Eshop_User_ErrorPage";
			}			

			return "Eshop_SalesManager_ShowList";
		}

		//ViewAll reports
		else 
		{
			value=1;
			try 
			{
				orderList=(ArrayList<Order>) bo.getOrderList(value,fromDate,toDate);
			}
			catch (DataAccessException e) 
			{
				model.addAttribute("errorMessage",e.getMessage());
				return "Eshop_User_ErrorPage";
			}
			if(orderList!=null)
			{
				model.addAttribute("condition",true);
				session.setAttribute("orderList",orderList);
			}
			return "Eshop_SalesManager_ShowList";
		}

	}


	/*****************************************************************************************************
	 * Method Name:viewByDate
	 * Description:Displays details of orders placed between the two dates.
	 * Return Type:String 
	 * @param @RequestParam(value="demo1") String date1
	 * @param:@RequestParam(value="demo2") String date2
	 * @param: Model object
	 * @param: HttpSession object
	 *****************************************************************************************************/

	@RequestMapping(value="/viewByDate")
	public String viewByDate(@RequestParam(value="demo1") String date1,@RequestParam(value="demo2") String date2,Model model,HttpSession session)
	{	
		if(!"".equals(date1) && !"".equals(date2))
		{
			try 
			{
				fromDate=new SimpleDateFormat("dd-MMM-yyyy").parse(date1);
				toDate=new SimpleDateFormat("dd-MMM-yyyy").parse(date2);
			} 
			catch (ParseException e) 
			{
				model.addAttribute("errorMessage",e.getMessage());
				return "Eshop_User_ErrorPage";
			}
			//conversion ends	
			try {
				value=3;
				orderList=(ArrayList<Order>) bo.getOrderList(value,fromDate,toDate);

			}
			catch (DataAccessException e) 
			{
				model.addAttribute("errorMessage",e.getMessage());
				return "Eshop_User_ErrorPage";
			}
			if(!(orderList.isEmpty()))
			{
				model.addAttribute("condition","true");
				session.setAttribute("orderList",orderList);
			}
			else
			{
				model.addAttribute("condition","false");
				session.setAttribute("orderList",orderList);
			}
		}
		else
		{
			model.addAttribute("spanMsg","Enter all the fields");
			return "Eshop_SalesManager_RecordsByDate";
		}
		return "Eshop_SalesManager_ShowList";
	}






	/************************************************************************************************************************************
	 * Method Name:prepareLogoutPage
	 * Description:
	 * Return Type:String 
	 * @param:Model Object
	 ***********************************************************************************************************************************/
	@RequestMapping(value="prepareLogoutPage")
	public String prepareLogoutPage(Model model)
	{
		session.removeAttribute("isLogged");
		return "Eshop_Customer_HomePage";
	}

	/************************************************************************************************************************************
	 * Method Name:proceedToUpdate
	 * Description:retrives data like categories and products to be displayed on the home screen.
	 * Return Type:String 
	 * @param:Model Object
	 ***********************************************************************************************************************************/

	@RequestMapping(value="proceedToUpdate")
	public String proceedToUpdate(@RequestParam("SUBMIT") String buttonValue,Model model)
	{
		if("Update Product".equals(buttonValue))
		{
			return "Eshop_Customer_HomePage";
		}
		else
		{
			try
			{
				subCategoryList=bo.getSubCategories();
				session.setAttribute("subCategoryList",subCategoryList);
				product.setProductImage(productImage);
				model.addAttribute("product", new Product());
				return "Eshop_Admin_AddProduct";
			}
			catch(DataAccessException e)
			{
				model.addAttribute("errorMessage",e.getMessage());
				return "Eshop_User_ErrorPage";
			}

		}
	}

	/************************************************************************************************************************************************************************************
	 * Method Name:updateProduct
	 * Description:  This method takes two different requests to update product details and to return to admin home page. It also takes the new product image file name(if required)
	 * Return Type:String 
	 * @param:Model Object,String productId
	 **************************************************************************************************************************************************************************************/

	@RequestMapping(value="updateProduct")
	public String updateProduct(@RequestParam("SUBMIT") String operation, @RequestParam("file") String fileName,@ModelAttribute("product") @Valid Product product,BindingResult result,Model model)
	{
		String target="";
		if(result.hasErrors())
		{
			target= "Eshop_Admin_UpdateProduct";
		}
		else
		{
			if("Update Product".equals(operation))
			{

				String updateImage=null;

				if(!"".equals(fileName))
				{		
					updateImage=fileName;
				}
				else
				{
					updateImage=(String) session.getAttribute("image");
				}

				int updateStatus=bo.updateProduct(product,updateImage);
				String spanMsg="";
				if(updateStatus==1)
				{
					spanMsg="Product updated successfully ";	
				}
				else if(updateStatus==2)
				{	
					spanMsg="Choose an appropriate file";
				}	
				else
				{
					spanMsg="Some problem occured,could not update!";
				}
				model.addAttribute("spanMsg",spanMsg);
				target="Eshop_Admin_UpdateProduct";
			}
		}
		return target;
	}

	/******************************************************************************************************************************************
	 * Method Name:processAddPage
	 * Description:Sends the product details to the service layer to be inserted into the database
	 * Return Type:String 
	 * @param:@RequestParam("file") String filename
	 * @param:@ModelAttribute("Product") @Valid Product product
	 * @param:BindingResult result
	 * @param:Model model
	 ***********************************************************************************************************************************/
	@SuppressWarnings("unused")
	@RequestMapping(value="AddProduct")
	private String processAddPage(@RequestParam("file") String filename,@ModelAttribute("product") @Valid Product product,BindingResult result,Model model)
	{
		int noOfRows=0;
		if(result.hasErrors())
		{
			return "Eshop_Admin_AddProduct";
		}
		else
		{
			productImage.setImage(filename);
			product.setProductImage(productImage);
			try
			{
				noOfRows=bo.addProduct(product);
				if(noOfRows>0)
				{
					model.addAttribute("product",new Product());
					model.addAttribute("spanMsg","Product Added Succesfully");
					return "Eshop_Admin_AddProduct";
				}
				else
				{
					model.addAttribute("errorMsg","Error Adding Product");
					return "Eshop_User_ErrorPage";
				}
			}
			catch(DataAccessException e)
			{
				model.addAttribute("errorMessage",e.getMessage());
				return "Eshop_User_ErrorPage";
			}
		}
	}


	/************************************************************************************************************************************
	 * Method Name:preparePlaceOrder
	 * Description:Navigate user to the PlaceOrder Page
	 * Return Type:String 
	 ***********************************************************************************************************************************/
	@SuppressWarnings("unused")
	@RequestMapping(value="/PlaceOrder")
	private String preparePlaceOrder()
	{
		return "Eshop_User_PlaceOrder";
	}

	/************************************************************************************************************************************
	 * Method Name:processPlaceOrder
	 * Description:Sends the order details to the service layer to be inserted into the database
	 * Return Type:String 
	 * @param:@RequestParam("SUBMIT") String submit,@RequestParam("totalAmount") String total
	 ***********************************************************************************************************************************/
	@SuppressWarnings({ "unused", "unchecked" })
	@RequestMapping(value="ProcessOrder")
	private String processPlaceOrder(@RequestParam("SUBMIT") String submit,@RequestParam("totalAmount") String total,Model model)
	{
		String target="";
		if("Confirm Order".equals(submit))
		{
			cartList=(List)session.getAttribute("cartList");
			boolean flag=false;
			String userId=(String) session.getAttribute("isLogged");
			try
			{
				flag = bo.insertOrderDetails(cartList,Double.parseDouble(total),userId);
				if(flag)
				{
					target="Eshop_User_Success";
				}
				else
				{
					target="Eshop_User_HomePage";

				}
			}
			catch(DataAccessException e)
			{
				model.addAttribute("errorMessage",e.getMessage());
				return "Eshop_User_ErrorPage";
			}
		}
		return target;
	}

	/************************************************************************************************************************************
	 * Method Name: proceedToHomePage
	 * Description:Navigate user to the Home Page
	 * Return Type:String 
	 ***********************************************************************************************************************************/
	@SuppressWarnings("unused")
	@RequestMapping(value="/Eshop_User_HomePage")
	private String proceedToHomePage()
	{
		return "Eshop_User_HomePage";
	}

	/************************************************************************************************************************************************
	 * Method name:PrepareChangePassword
	 * Parameters:Model
	 * return type:String
	 * Description:Prepares the ChangePassword page
	 ****************************************************************************************************************************/
	@RequestMapping(value="/ChangePass")
	public String prepareChangePassword(Model model)
	{
		UserCredentials user=new UserCredentials();
		model.addAttribute("user",user);
		return "Eshop_User_ChangePassword";
	}


	/****************************************************************************************************************
	 * Method name:changePassword
	 *Description:Checks the username and password and performs the corresponding update.
	 * Parameters:ModelAttribute,BindingResult,Model
	 * return type:String

	 ****************************************************************************************************************/

	@RequestMapping(value="/changePassword")
	public String changePassword(@ModelAttribute("user") @Valid UserCredentials user,BindingResult result,Model model)
	{
		if(result.hasErrors())
		{

			return "Eshop_User_ChangePassword";
		}

		//Logic to validate userName and password against database
		int userPresent=0;

		userPresent=(int) bo.isValidUser(user);
		if(userPresent>0)
		{
			//Logic to perform updation of password in database
			int noOfrows=bo.changePassword(user);
			if(noOfrows>0)
			{
				model.addAttribute("message","Updated Successfully");
				return "Eshop_User_Login";
			}
			else
			{
				model.addAttribute("message","Updation failed.");
				return "Eshop_User_ChangePassword";
			}
		}
		else
		{
			model.addAttribute("message","Enter valid UserName/Password");
			model.addAttribute("status","true");
			return "Eshop_User_ChangePassword";
		}
	}

	/************************************************************************************************
	 * Method name:PrepareAdminHomePage
	 * Description:Prepares the PrepareAdminHomePage page
	 * Parameters:Model
	 * return type:String
	 ************************************************************************************************/
	@RequestMapping(value="AdminHomePage")
	public String prepareAdminHomePage(Model model)
	{
		return "Eshop_Admin_HomePage";
	}

	/************************************************************************************************
	 * Method name:PrepareSalesHomePage
	 * Description:Prepares the Sales manager HomePage page
	 * Parameters:Model
	 * return type:String
	 ************************************************************************************************/
	@RequestMapping(value="SalesHomePage")
	public String PrepareSalesHomePage(Model model)
	{
		return "Eshop_SalesManager_ViewReports";
	}

	/************************************************************************************************
	 * Method name:PrepareResetProduct
	 * Description:Prepares the Reset product on the update page.
	 * Parameters:Model
	 * return type:String
	 ************************************************************************************************/
	@RequestMapping(value="PrepareResetProduct")
	public String PrepareResetProduct(Model model)
	{
			Product updateProdcut=(Product) session.getAttribute("update product");
			model.addAttribute("product", updateProdcut);
			return "Eshop_Admin_UpdateProduct";
	}	
}


