package com.igate.eshop.bo;

import java.util.Date;
import java.util.List;
import java.util.Map;
import com.igate.eshop.entity.Customer;
import com.igate.eshop.entity.Order;
import com.igate.eshop.entity.Product;
import com.igate.eshop.entity.SubCategory;
import com.igate.eshop.entity.User;
import com.igate.eshop.entity.UserCredentials;

/*******************************************************************************************************
 * File Name:	EshopBOInterface 
 * Package Name:	com.igate.eshop.bo
 * Description:	Consists of all the Method Declarations of those methods present in EshopBOImpl		
 * Version: 	1.0
 * Restrictions:	N/A
 * @author 	aa815803,mk815850,ss815801,ns815843,bv815844,nm815851,kp815871
 * Date:		24/12/2013
 ******************************************************************************************************/


public interface EshopBOInterface 
{
	public Product getProductDetails(String productId);
	public Map<String, List<String>> returnNavigationBarData();
	public List<Product> getProductDetailsList();
	public List<Product> getProductDetailsByCategory(String subCategoryName);
	public int registerUser (Customer customer);
	public User searchUser(User user);
	public int isValidUser(User user);
	public List<Product> getProductDetailsByName(String productName);
	public List<Order> getOrderList(int value, Date fromDate,Date toDate); 
	public abstract int updateProduct(Product product, String updateImage);
	public abstract boolean isValidFile(String fileName);
	public abstract List<SubCategory> getSubCategories();
	public int addProduct(Product product);
	public boolean insertOrderDetails(List<Product> cartList, double total, String userId);
	public int changePassword(UserCredentials user);
	public int isValidUser(UserCredentials user);
	public int isUserExists(User user);
}
